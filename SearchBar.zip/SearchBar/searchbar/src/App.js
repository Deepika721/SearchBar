import React, { useState, useEffect } from "react";
import "./App.css"; // Styling for the search bar page

// JSON data for countries and capitals (can be replaced with external data)
const countryData = [
  { name: "United States", capital: "Washington, D.C." },
  { name: "Canada", capital: "Ottawa" },
  { name: "Germany", capital: "Berlin" },
  { name: "India", capital: "New Delhi" },
  { name: "Australia", capital: "Canberra" },
  { name: "France", capital: "Paris" },
  { name: "Italy", capital: "Rome" },
  { name: "Brazil", capital: "Brasilia" },
  { name: "Japan", capital: "Tokyo" }
];

const App = () => {
  const [query, setQuery] = useState(""); // Stores the search input
  const [filteredResults, setFilteredResults] = useState([]); // Stores filtered results

  // Filter the country and capital data based on the search query
  useEffect(() => {
    const results = countryData.filter(
      (item) =>
        item.name.toLowerCase().includes(query.toLowerCase()) ||
        item.capital.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredResults(results);
  }, [query]);

  // Update query state when input changes
  const handleInputChange = (e) => {
    setQuery(e.target.value);
  };

  return (
    <div className="app">
      <div className="main-container">
        <h1>Country Search</h1>
        <p>Search by country name or capital</p>
        <div className="search-container">
          <input
            type="text"
            placeholder="Type a country or capital..."
            value={query}
            onChange={handleInputChange}
            className="search-input"
          />
          {query && (
            <ul className="suggestions-list">
              {filteredResults.length > 0 ? (
                filteredResults.map((result, index) => (
                  <li key={index} className="suggestion-item">
                    {result.name} - {result.capital}
                  </li>
                ))
              ) : (
                <li className="no-results">No results found</li>
              )}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
